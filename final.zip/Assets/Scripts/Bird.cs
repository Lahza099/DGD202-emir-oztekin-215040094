using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bird : MonoBehaviour
{
    public float speed;
    public GameObject effect;
    public GameObject ui;
    public GameObject gameovermenu;
    public GameObject levelcompletemenu;
    public bool spikes;
    private void Start()
    {
    }
    void Update()
    {
        if (spikes)
        {
        }
        else
        {
            transform.position += Vector3.right * speed * Time.deltaTime;
        }
        Physics2D.IgnoreLayerCollision(6, 8);
        Physics2D.IgnoreLayerCollision(8, 10);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("player"))
        {
            ui.SetActive(false);
            gameovermenu.SetActive(true);

            levelcompletemenu.SetActive(false);
            Vector2 v = new Vector2(transform.position.x - 1.5f, transform.position.y - 1f);
            GameObject impactGOO = Instantiate(effect, v, transform.rotation);
            Destroy(gameObject);
            Destroy(collision.gameObject);
            Destroy(impactGOO, 1f);
        }
    }
}
