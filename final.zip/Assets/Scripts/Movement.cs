using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Movement : MonoBehaviour
{
    public float speed = 10f;
    private bool leftMove;
    private bool rightMove;
    private float horizontalMove;
    public Rigidbody2D rb;
    public float jumpSpeed;
    private bool isGrounded;
    public Animator animator;

    private void Awake()
    {
        Time.timeScale = 1;
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
    }


    void Start()
    {
        GameObject.Find("game").GetComponent<CompositeCollider2D>().geometryType = CompositeCollider2D.GeometryType.Polygons;
        if (GameObject.Find("tiles") != null)
        {
            GameObject.Find("tiles").GetComponent<CompositeCollider2D>().geometryType = CompositeCollider2D.GeometryType.Polygons;

            GameObject.Find("tiles").layer = 8;
        }
        GameObject.Find("game").layer = 8;
    }

    void Update()
    { // Check for left and right arrow key presses or A/D keys
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
        {
            leftMove = true;
            rightMove = false;
        }
        else if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
        {
            rightMove = true;
            leftMove = false;
        }
        else
        {
            leftMove = false;
            rightMove = false;
        }

        // Update horizontalMove based on the keys pressed
        if (leftMove)
        {
            horizontalMove = -speed;
            transform.localScale = new Vector2(-1f, 1f);
            animator.SetBool("Run", true);
        }
        else if (rightMove)
        {
            horizontalMove = speed;
            transform.localScale = new Vector2(1f, 1f);
            animator.SetBool("Run", true);
        }
        else
        {
            horizontalMove = 0;
            animator.SetBool("Run", false);
        }

        // Move the player
        transform.position += new Vector3(horizontalMove * Time.deltaTime, 0, 0);
    

        // Call the Jump method on space key press
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Jump();
        }
    }

    private void FixedUpdate()
    {
        rb.velocity = new Vector2(horizontalMove, rb.velocity.y);
    

        // Debug log to check if the ground check is working
        Debug.Log("Is Grounded: " + isGrounded);
    }

    public void Jump()
    {
        if (isGrounded)
        {
            rb.AddForce(Vector2.up * jumpSpeed, ForceMode2D.Impulse);
            isGrounded = false;

            // Debug log to check if jump is being called
            Debug.Log("Jumping");
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("ground"))
        {
            isGrounded = true;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("ground"))
        {
            isGrounded = false;
        }
    }

    private void OnTriggerEnter2D(Collider2D collisiona)
    {
        if (collisiona.gameObject.CompareTag("coins"))
        {
            ScoreManager.instance.AddPoint();
            Destroy(collisiona.gameObject);
        }
    }
}
