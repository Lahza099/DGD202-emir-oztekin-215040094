using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shoot : MonoBehaviour
{
    public GameObject bullet, point;
    AudioSource t;
    private void Start()
    {
        t = GameObject.Find("gun").GetComponent<AudioSource>();
    }
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.L))
        {
            AttackEnemy();
        }
    }
    public void AttackEnemy()
    {
        GetComponent<Animator>().SetTrigger("Gun");
        t.Play();
        Instantiate(bullet, point.transform.position, Quaternion.identity);
    }
}
