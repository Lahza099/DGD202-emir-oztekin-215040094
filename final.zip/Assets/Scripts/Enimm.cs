using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enimm : MonoBehaviour
{
    public float speed = 5f;
    public Transform player;
    Vector2 positionToMoveTo;
    Vector3 oldPos;
    Quaternion oldRot;
    public Transform firePointt;
    public GameObject bulletEnemy;
    public float fireRate;
    float nextFire;
    public Animator animator;
    public float scale = 0.4f;
    AudioSource t;
    void Start()
    {
        nextFire = Time.time;
        t = GameObject.Find("tank").GetComponent<AudioSource>();
    }
    void Update()
    {
        Physics2D.IgnoreLayerCollision(6, 9);
        if (player != null)
        {
            float dist = Vector2.Distance(transform.position, player.position);

            if (dist < 4)
            {
                animator.SetBool("Attack", true);
                TimeFire();
            }

            else
            {
                animator.SetBool("Attack", false);
                positionToMoveTo = new Vector2(player.position.x, player.position.y);
                transform.position = Vector2.MoveTowards(transform.position, positionToMoveTo, speed * Time.deltaTime);
                Vector3 movement = oldRot * (transform.position - oldPos);
                if (transform.position.x < player.transform.position.x)
                {

                    transform.localScale = new Vector2(scale, scale);
                }
                else if (movement.x > player.transform.position.x)
                {
                    transform.localScale = new Vector2(-scale, scale);
                    
                }
                oldPos = transform.position;
                oldRot = transform.rotation;
            }
        }
    }


    void TimeFire()
    {
        if (Time.time > nextFire)
        {
            t.Play();
            GameObject bullet = Instantiate(bulletEnemy, firePointt.position, firePointt.rotation);
            bullet.GetComponent<Bullet>().player = gameObject;
            nextFire = Time.time + fireRate;
        }
    }
}