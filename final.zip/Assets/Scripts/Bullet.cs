using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float bulletSpeed = 10f;
    public Rigidbody2D rb2;
    public int damage = 10;
    public GameObject impactEffect;

    public GameObject player;
    public string t = "enemy";
    public bool plyer;
    void Start()
    {
        if (plyer)
        {
            player = GameObject.FindWithTag(t);
            Vector3 local = player.transform.localScale;
            if (local.x == 1)
            {
                rb2.velocity = transform.right * bulletSpeed;
                transform.localScale = new Vector2(0.1f,0.1f);
            }
            else if (local.x == -1)
            {
                transform.localScale = new Vector2(-0.1f,0.1f);
                rb2.velocity = Vector2.left * bulletSpeed;
            }
        }
        else
        {
            Vector3 local = player.transform.localScale;
            if (local.x == player.GetComponent<Enimm>().scale)
            {
                rb2.velocity = transform.right * bulletSpeed;
            }
            else if (local.x == -player.GetComponent<Enimm>().scale)
            {
                rb2.velocity = Vector2.left * bulletSpeed;
            }
        }
    }

    void OnTriggerEnter2D(Collider2D hitInfo)
    {
        Enemy enem = hitInfo.GetComponent<Enemy>();
        if (enem != null)
        {
            enem.TakeDamage(damage);
        }
        GameObject impactGO = Instantiate(impactEffect, transform.position, transform.rotation);
        Destroy(gameObject);
        Destroy(impactGO, 0.06f);
    }
}