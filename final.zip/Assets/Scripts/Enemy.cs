using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour
{
    public int maxHealth;
    public GameObject deathEffect;
    public int currentHealth = 0;
    public bool player;
    public int scoress;
    public Image health1;
    public Image health2;
    public Image health3;

    public GameObject ui;
    public GameObject gameovermenuu;
    public GameObject levelcompletemenuu;

    void Start()
    {
        if (player == false)
        {
            currentHealth = maxHealth;
        }

    }

     
    private void Awake()
    {
        if (player)
        {
            int current = PlayerPrefs.GetInt("current", 30);
            currentHealth = current;
            if (current == 20)
            {
                health3.enabled = false;
            }

            if (current == 10)
            {
                health2.enabled = false;
                health3.enabled = false;
            }


            if (current == 0)
            {
                health2.enabled = false;
                health3.enabled = false;
                health1.enabled = false;
            }
        }
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        if (currentHealth == 0 && player)
        {
            Dieee();
        }
        else if (currentHealth == 0 && player == false)
        {
            DieeEe();
            ScoreManager.instance.AddPoint();
        }
    }

    void Update()
    {
        if (player)
        {
            PlayerPrefs.SetInt("current", currentHealth);
            if (currentHealth == 20)
            {
                health3.enabled = false;
            }

            if (currentHealth == 10)
            {
                health2.enabled = false;
                health3.enabled = false;
            }
           
        }
    }
    void Dieee()
    {
        health1.enabled = false;
        ui.SetActive(false);
        gameovermenuu.SetActive(true);
        levelcompletemenuu.SetActive(false);
        Vector2 v = new Vector2(transform.position.x, transform.position.y - 0.2f);
        GameObject impactGOO = Instantiate(deathEffect, v, transform.rotation);
        Destroy(gameObject);
        Destroy(impactGOO, 1f);
    }


    void DieeEe()
    {
        Vector2 v = new Vector2(transform.position.x, transform.position.y);
        GameObject impactGOO = Instantiate(deathEffect, v, transform.rotation);
        Destroy(gameObject);
        Destroy(impactGOO, 1f);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (player)
        {
            if (collision.CompareTag("flags"))
            {
                    ui.SetActive(false);
                    gameovermenuu.SetActive(false);
                    levelcompletemenuu.SetActive(true);
                    Time.timeScale = 0;
            }

           /* if (collision.CompareTag("flagsok"))
            {
                    ui.SetActive(false);
                    gameovermenuu.SetActive(false);
                    levelcompletemenuu.SetActive(true);
                    Time.timeScale = 0;
                    Destroy(gameObject);
            }
           */
            if (collision.CompareTag("heart"))
            {
                currentHealth += 10;
                if (health3.enabled == true)
                {
                    currentHealth = 30;
                }
                if (currentHealth == 30)
                {
                    health3.enabled = true;
                    health2.enabled = true;
                    health1.enabled = true;
                }
                if (currentHealth == 20)
                {
                    health3.enabled = false;
                    health2.enabled = true;
                    health1.enabled = true;
                }

                if (currentHealth == 10)
                {
                    health3.enabled = false;
                    health2.enabled = false;
                    health1.enabled = true;
                }
                Destroy(collision.gameObject);
            }
        }
    }
}
