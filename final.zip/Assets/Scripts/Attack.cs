using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Attack : MonoBehaviour
{
    public Transform attackPoint;
    public float attackRange = 0.5f;
    public LayerMask enemyLayers;
    public Animator animator;
    public Button btn;
    AudioSource t;
    private void Start()
    {
        t = GameObject.Find("knife").GetComponent<AudioSource>();
    }
    
    public void AttackEnemy()
    {
        btn.interactable = false;
        t.Play();
        animator.SetTrigger("Attack");
        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(attackPoint.position, attackRange, enemyLayers);

            foreach (Collider2D enemy in hitEnemies)
            {
                enemy.GetComponent<Enemy>().TakeDamage(10);
            }
        
    }
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            AttackEnemy();
        }
        if (animator.GetCurrentAnimatorStateInfo(0).IsName("Idle") &&
            animator.GetCurrentAnimatorStateInfo(0).normalizedTime < 1.0f)
        {
            btn.interactable = true;
        }
        //Physics2D.IgnoreLayerCollision(6, 7);
    }
    void OnDrawGizmosSelected()
    {
        if (attackPoint == null)
            return;

        Gizmos.DrawWireSphere(attackPoint.position, attackRange);

    }
}
