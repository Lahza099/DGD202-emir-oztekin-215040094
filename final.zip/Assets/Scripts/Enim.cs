using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enim : MonoBehaviour
{
    public float speed = 5f;
    public Transform player;
    Vector2 positionToMoveTo;
    Vector3 oldPos;
    Quaternion oldRot;
    public Transform firePointt;
    public GameObject bulletEnemy;
    public float fireRate;
    float nextFire;
    public Animator animator;

    public float attackRange = 0.5f;
    public LayerMask enemyLayers;
    bool fired;
    public bool canfire;
    public float scale = 1;
    AudioSource t;
    void Start()
    {
        nextFire = Time.time;
        t = GameObject.Find("knife").GetComponent<AudioSource>();
    }
    void Update()
    {
        Physics2D.IgnoreLayerCollision(6, 9);
        Physics2D.IgnoreLayerCollision(7, 8);
        if (player != null)
        {
            float dist = Vector2.Distance(transform.position, player.position);

            if (dist < 1)
            {
                animator.SetBool("Run", false);
                    TimeFire();
            }

            else
            {
                animator.SetBool("Run", true);
                positionToMoveTo = new Vector2(player.position.x, player.position.y);
                transform.position = Vector2.MoveTowards(transform.position, positionToMoveTo, speed * Time.deltaTime);
                Vector3 movement = oldRot * (transform.position - oldPos);
                if (transform.position.x < player.transform.position.x)
                {

                    transform.localScale = new Vector2(-scale, scale);
                }
                else if (movement.x > player.transform.position.x)
                {
                    transform.localScale = new Vector2(scale, scale);
                }
                oldPos = transform.position;
                oldRot = transform.rotation;
            }
        }
    }


    void TimeFire()
    {
        if (!fired)
        {
                t.Play();
            Vector3 movement = oldRot * (transform.position - oldPos);
            if (movement.x > 0)
            {

                transform.localScale = new Vector2(scale, scale);
            }
            else if (movement.x < 0)
            {
                transform.localScale = new Vector2(-scale, scale);
            }
            animator.SetTrigger("Attack");
            Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(firePointt.position, attackRange, enemyLayers);

            foreach (Collider2D enemy in hitEnemies)
            {
                enemy.GetComponent<Enemy>().TakeDamage(10);
            }
            fired = true;
            Invoke("firedd", 2f);
        }
        
    }
    public void firedd()
    {
        fired = false;
    }
    void OnDrawGizmosSelected()
    {
        if (firePointt == null)
            return;

        Gizmos.DrawWireSphere(firePointt.position, attackRange);

    }
}