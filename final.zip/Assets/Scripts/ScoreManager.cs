using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager instance;
    public Text scoreText;

    public static int score = 0;
    public static int highScore = 0;



    private void Awake()
    {
        instance = this;
    }

    void Start()
    {
        score = PlayerPrefs.GetInt("score", 0);
        scoreText.text = "COINS: "+PlayerPrefs.GetInt("score", 0);
        scoreText.text = "COINS: " + score.ToString();
    }

    public void AddPoint()
    {
        score += 1;
        scoreText.text = "COINS: " + score.ToString();
        PlayerPrefs.SetInt("score", score);
        if (score > PlayerPrefs.GetInt("highScore", 0))
        {
            PlayerPrefs.SetInt("highScore", score);

        }
    }
    /*public void AddBug()
    {
        bug += 1;
        bugText.text = bug.ToString() +"/"+"10";
    }
    */
}
