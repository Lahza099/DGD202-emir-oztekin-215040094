using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    private void Awake()
    {
        Time.timeScale = 1;
    }

    public void Level()
    {
        PlayerPrefs.DeleteAll();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void Collect()
    {
        PlayerPrefs.DeleteAll();
        int y = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(y);
    }
    private int currentLevel;

    public void Change()
    {
            int y = SceneManager.GetActiveScene().buildIndex;
            SceneManager.LoadScene(y + 1);
        if (currentLevel < 50) // Assuming there are 50 levels
        {
            currentLevel++; // Increment the current level
            PlayerPrefs.SetInt("CurrentLevel", currentLevel); // Save the updated level
            PlayerPrefs.SetInt("Level" + currentLevel, 1);
            PlayerPrefs.Save();
        }
    }
    public void Main()
    {
        SceneManager.LoadScene(0);
    }
    void Start()
    {

        // Retrieve the current level index
        currentLevel = PlayerPrefs.GetInt("CurrentLevel", 1); // Default to 1 if not set
    }
}
